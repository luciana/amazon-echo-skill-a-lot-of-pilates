var config = {};
  
 config.api_key = 'be65fe76147759d7931718826f7db263'; 
 config.host_name = 'www.alotofpilates.com';
 config.host = 'https://www.alotofpilates.com';
 config.api_secret ='MPP-Allow-API-Call';
  
module.exports = config;